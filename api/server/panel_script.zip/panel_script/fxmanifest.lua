server_script "server/server.js"
client_script "client/client.js"